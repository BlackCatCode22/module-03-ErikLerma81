package mystuff;

public class Driver {
    public static void main(String[] args) {
    Devices user = new Devices();

    user.hasAppleWatch = false;
    user.hasCharger = true;
    user.hasIpad = false;
    user.hasPC = true;
    user.hasPhone = true;
    user.hasTV = true;
    user.hasLaptop = true;

    System.out.println( "its " + user.hasLaptop + ", that the user has a laptop");
    System.out.println( "its " + user.hasAppleWatch + ", that the user has a Apple Watch");
    System.out.println( "its " + user.hasCharger + ", that the user has a has a charger");
    System.out.println( "its " + user.hasPC + ", that the user has a has a PC");
    System.out.println( "its " + user.hasPhone + ", that the user has a Phone");
    System.out.println( "its " + user.hasTV + ", that the user has a TV");
    System.out.println( "its " + user.hasIpad + ", that the user has a Ipad");
    }
}