package mystuff;

public class Devices {
    boolean hasLaptop;
    boolean hasPhone;
    boolean hasPC;
    boolean hasCharger;
    boolean hasIpad;
    boolean hasAppleWatch;
    boolean hasTV;
}
