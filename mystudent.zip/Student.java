package mystudent;

public class Student {
    String firstname;
    String lastname;
    double gpa;
    String major;
    int age;
    boolean onProbation;
}
