package mystudent;

import java.util.Scanner;
public class App {
    public static void main(String[] args) {

    Student Student1 = new Student();
    Student1.firstname = "Jim";
    Student1.lastname = "Halpert";
    Student1.major = "Business";
    Student1.gpa = 2.3;
    Student1.age = 24;
    Student1.onProbation = false;

    System.out.println(Student1.firstname);

    Student Student2 = new Student();
    Student2.firstname = "Pam";
    Student2.lastname = "Beasley";
    Student2.major = "Art";
    Student2.gpa = 2.3;
    Student2.age = 24;
    Student2.onProbation = true;

    System.out.println(Student2.firstname);
    }
}