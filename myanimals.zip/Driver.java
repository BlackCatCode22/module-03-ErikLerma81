package myanimals;

public class Driver {
    public static void main(String[] args) {

        Cat cat1 = new Cat();
        System.out.println("Total number of dogs and cats: " + Animal.TotalAnimals);
        Dog dog1 = new Dog();
        System.out.println("Total number of dogs and cats: " + Animal.TotalAnimals);

        Cat cat2 = new Cat();
        System.out.println("Total number of dogs and cats: " + Animal.TotalAnimals);
        Dog dog2 = new Dog();
        System.out.println("Total number of dogs and cats: " + Animal.TotalAnimals);

        Cat cat3 = new Cat();
        System.out.println("Total number of dogs and cats: " + Animal.TotalAnimals);
        Dog dog3 = new Dog();
        System.out.println("Total number of dogs and cats: " + Animal.TotalAnimals);

    }
}