package myanimals;

public class Dog extends Animal {

    public Dog(){
        System.out.println("Woof");
    }
}
