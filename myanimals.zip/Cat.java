package myanimals;

public class Cat extends Animal {

    public Cat(){
        System.out.println("Meow");
    }
}
