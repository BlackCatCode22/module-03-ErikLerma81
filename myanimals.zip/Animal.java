package myanimals;

public class Animal {

    static int TotalAnimals = 0;

    String NoiseOfAnimal;


    public Animal(){
    TotalAnimals++;

    }

    public static int getAnimalCount(){
        return TotalAnimals;
    }

}